module.exports = {
  content: ['views/**/*.ejs'],
  css: ['static/assets/bootstrap.css'],
  output: 'static/assets/bootstrap.min.css',
  safelist: ['fade', 'collapsing']
};
